Under Construction Page
=======================

Features
--------

- Creative Commons licensed construction picture (found on [Flickr CC page][])
- Centered box with text in it
- Responsive design that scales for different screen sizes

Copying
-------

To the extent possible under law, the author has dedicated all copyright and related and neighboring rights to this software to the public domain worldwide. This software is distributed without any warranty.

You should have received a copy of the CC0 Public Domain Dedication along with this software. If not, see <http://creativecommons.org/publicdomain/zero/1.0/>.

[flickr cc page]: http://www.flickr.com/creativecommons/
